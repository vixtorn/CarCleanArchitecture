---
name: Car Inventory
colors:
  surface: '#f8f9ff'
  surface-dim: '#d0dbed'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dee9fc'
  surface-container-highest: '#d9e3f6'
  on-surface: '#121c2a'
  on-surface-variant: '#3f4940'
  inverse-surface: '#27313f'
  inverse-on-surface: '#eaf1ff'
  outline: '#6f7a6f'
  outline-variant: '#bfc9bd'
  surface-tint: '#116d37'
  primary: '#116d37'
  on-primary: '#ffffff'
  primary-container: '#65b87a'
  on-primary-container: '#004620'
  inverse-primary: '#84d998'
  secondary: '#4f6357'
  on-secondary: '#ffffff'
  secondary-container: '#d2e8d8'
  on-secondary-container: '#55695c'
  tertiary: '#2e6a3f'
  on-tertiary: '#ffffff'
  tertiary-container: '#77b583'
  on-tertiary-container: '#014720'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a0f6b2'
  primary-fixed-dim: '#84d998'
  on-primary-fixed: '#00210c'
  on-primary-fixed-variant: '#005226'
  secondary-fixed: '#d2e8d8'
  secondary-fixed-dim: '#b6ccbd'
  on-secondary-fixed: '#0d1f16'
  on-secondary-fixed-variant: '#384b3f'
  tertiary-fixed: '#b1f2bb'
  tertiary-fixed-dim: '#96d5a1'
  on-tertiary-fixed: '#00210b'
  on-tertiary-fixed-variant: '#125129'
  background: '#f8f9ff'
  on-background: '#121c2a'
  surface-variant: '#d9e3f6'
typography:
  display:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  xxl: 48px
  container-max: 1440px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style
The design system is built for high-utility inventory management, emphasizing a **Corporate/Modern** aesthetic that prioritizes clarity, efficiency, and a calm working environment. The visual narrative is defined by a "Fresh Professionalism"—moving away from cold, sterile enterprise grays toward a revitalizing light green and white palette. 

The target audience consists of dealership managers and logistics coordinators who require a tool that reduces cognitive load during high-density data entry and analysis. The UI evokes a sense of organized precision through generous whitespace, high-quality typography, and a "soft-utilitarian" approach where every element feels grounded and intentional.

## Colors
The palette is rooted in a refreshing "Alpine Mint" spectrum to maintain a calm atmosphere for power users. 

- **Primary Green (#65B87A):** Used for primary actions, success states, and key data points. It is the core functional color.
- **Surface & Background:** The page uses a tinted off-white (#F4FAF5) to reduce screen glare, while UI cards use pure white (#FFFFFF) to pop against the background.
- **Hierarchy of Green:** Use the light accent (#DDF3E3) for ghost buttons and row highlights. Use the deep green (#2F6B40) sparingly for high-contrast text or icons that need to stand out against primary green backgrounds.
- **Typography Colors:** Maintain strict adherence to Dark Charcoal (#1F2937) for all primary reading paths to ensure AAA accessibility. Use the Slate Gray (#6B7280) for meta-data and labels.

## Typography
This design system utilizes a dual-font approach to balance technical precision with readability. 

**Geist** is reserved for headlines, labels, and numerical data. Its technical, slightly monospaced character widths make it ideal for inventory lists and VIN numbers where character distinction is critical. 

**Inter** is the workhorse for body text and long-form descriptions. It provides a familiar, neutral reading experience that excels in data-heavy environments. 

For mobile devices, headlines scale down to prevent text wrapping on long vehicle names. Numerical data should always use `label-md` or `label-sm` to ensure the clean, geometric nature of the numbers is preserved.

## Layout & Spacing
The layout follows a **Fluid Grid** model with a maximum container width of 1440px for desktop views. 

- **Desktop (1024px+):** 12-column grid with 24px gutters and 32px side margins. 
- **Tablet (768px - 1023px):** 8-column grid with 20px gutters and 24px margins.
- **Mobile (<767px):** 4-column grid with 16px gutters and 16px margins.

Spacing follows a 4px baseline rhythm. For inventory dashboards, use the `md` (16px) unit for internal card padding and the `lg` (24px) unit for spacing between major UI modules. Content reflow should prioritize the data table, which may transition to a "card-list" view on mobile devices.

## Elevation & Depth
Depth in this design system is achieved through **Low-Contrast Outlines** combined with **Ambient Shadows**. 

- **Level 0 (Background):** Solid #F4FAF5 background. No shadow.
- **Level 1 (Cards/Tables):** White surface with a 1px solid border (#DCE8DF). Use a very soft, diffused shadow: `0px 2px 4px rgba(31, 41, 55, 0.04)`.
- **Level 2 (Popovers/Dropdowns):** White surface with a 1px solid border (#DCE8DF). Increased shadow depth: `0px 10px 15px -3px rgba(31, 41, 55, 0.08)`.

Avoid using heavy shadows or dark borders. The goal is to make elements look like they are resting lightly on the surface, not floating far above it.

## Shapes
The shape language is **Rounded**, using a standard 8px radius for most interface elements. This strikes a balance between the "friendly" nature of the green palette and the "professional" requirement of a business dashboard.

- **Standard Elements (Buttons, Inputs, Cards):** 8px (0.5rem).
- **Larger Containers:** 16px (1rem) for main dashboard sections.
- **Small Elements (Tags, Badges):** 4px (0.25rem) to maintain sharpness at small scales.

Buttons should never be fully pill-shaped; they should maintain the consistent 8px radius to match the input fields and cards, creating a unified "block" feel across the inventory forms.

## Components

### Buttons
- **Primary:** Solid #65B87A with white text. 150ms ease-in-out transition to a slightly darker tint on hover.
- **Secondary:** Solid #DDF3E3 with #2F6B40 text. No border.
- **Tertiary/Ghost:** Transparent background with #6B7280 text; transitions to a light gray background on hover.

### Data Tables
- **Header:** Light gray background or subtle #F4FAF5 tint. Text in `label-sm` (uppercase, #6B7280).
- **Rows:** 1px bottom border (#DCE8DF). On hover, the entire row should transition to a #F4FAF5 background.
- **Cells:** Use `body-sm` for standard text and `label-md` for price/VIN data.

### Input Fields
- **Default State:** 1px solid border (#DCE8DF), 8px corner radius. White background.
- **Focus State:** 1px solid #65B87A with a 3px soft outer glow (rgba(101, 184, 122, 0.2)).
- **Icons:** Use 16px or 20px line-icons in #6B7280, placed 12px from the left edge.

### Stat Cards
- Compact layout featuring a `label-sm` title, a `headline-md` value, and a small sparkline or percentage indicator in the bottom corner.

### Chips/Badges
- Used for "Status" (e.g., In Stock, Sold, Pending).
- Use a "Soft Tint" style: Background is a 10% opacity version of the status color (Green, Amber, or Red) with high-contrast text.